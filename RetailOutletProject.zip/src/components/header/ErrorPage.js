
import React from 'react';
//import ReactDOM from 'react-dom';

class ErrorPage extends React.Component{
    render(){
        return(
            <div>
                <h1>Page 404 found</h1>
            </div>
        )
    }
}
export default ErrorPage;