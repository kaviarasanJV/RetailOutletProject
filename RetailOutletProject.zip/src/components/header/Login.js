import React from 'react';
//import ReactDOM from 'react-dom';

function login(){

    const formSubmit=()=>
    {
        alert("form submitted");
    }

return(
    <form onSubmit={formSubmit}> 
        <h1><label for="fname">Login Id: </label></h1>
         <input type="text" name="username"/>

        <h1><label for="fname">Password:</label></h1>
         <input type="text" name="age"/>
        
        <h1><label for="fname" > USER TYPE: </label></h1>
        <select id="staffcustomer" name="staffcustomer">
            <option value="CUSTOMER">CUSTOMER</option>
            <option value="IOCSTAFF">IOC STAFF</option>
        </select>
        <input type="submit"/>
    </form>

)

}
export default login;