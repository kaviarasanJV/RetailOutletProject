import React from 'react';
//import ReactDOM from 'react-dom';
import {useState} from 'react';
import FileUploadPage from './FileUploadPage.js';

function Register(){
    const [getFirstname,updateFirstname]=useState();
    const [getLastname,updateLastname]=useState();
    const [getMobile,updateMobile]=useState();
    const [getVehicle,updateVehicle]=useState();

    const formSubmit=(event)=>
    {
        event.preventDefault();
        alert("form submitted formSubmit active");
        const informationDetails={
                Fname:getFirstname,
                Lname:getLastname,
                Mobile:getMobile,
                Vehicle:getVehicle
        }
        console.log("submitted data",informationDetails);
        updateFirstname('');
        updateLastname('');
        updateMobile('');
        updateVehicle('');
    }

    //event is an object
    const changeFirstnameHandler=(event)=>
    {
        //alert(event.target.value);
        updateFirstname(event.target.value);
    }

    const changeLastnameHandler=(event)=>
    {
        //alert(event.target.value);
        updateLastname(event.target.value);
    }

    const changeMobileHandler=(event)=>
    {
        //alert(event.target.value);
        alert(event.target.value);
        updateMobile(event.target.value);
        console.log(event.target.value);
    }

    const changeVehicleHandler=(event)=>
    {
        //alert(event.target.value);
        updateVehicle(event.target.value);
    }
//const style1={}
return(
    //The code written in parentheisis are JSX code
    //If you want to write the JAVASCRIPT inside the JSX, use the curly braces
    
    <div >
        {getFirstname}-{getLastname}-{getMobile}-{getVehicle}
    <form onSubmit={formSubmit} >
        <div className="borderColor">
        <h1><label for="fname">First name: </label></h1>
        <input type="text" name="firstname" value={getFirstname} onChange={changeFirstnameHandler}/>
        </div>
        
        <div className="borderColor">
        <h1><label for="lname">Last name: </label></h1>
        <input type="text" name="lastname" value={getLastname} onChange={changeLastnameHandler}/>
        </div>
        
        <div className="borderColor">
        <h1><label for="mobile">Mobile: </label></h1>
        <input type="number" name="mobile" value={getMobile} onChange={changeMobileHandler}/>
        </div>

        <div className="borderColor">
        <h1><label for="vehicleusage">vehicle usage: </label></h1>
        <select id="vehicle" name="vehicle" value={getVehicle} onChange={changeVehicleHandler}>
            <option value="2wheelers">2wheelers</option>
            <option value="3wheelers">3wheelers</option>
            <option value="4wheelers">4wheelers</option>
            <option value="HeavyVehicles">HeavyVehicles</option>
        </select>
        </div>
        <div className="SubmitButton">
        <input type="submit" value="Submit"/>
        </div>
    </form>

    <div className="widthProperty">
        <FileUploadPage/>
        </div>
    </div>
    
);
}
export default Register;