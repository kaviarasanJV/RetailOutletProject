
import React from 'react';
//import ReactDOM from 'react-dom';

class About extends React.Component{
    render(){
        return(
            <div>
                <h1>
                    J.V.AGENCIES is a Retail Outlet serving the people for the past 25 years
                </h1>
            </div>
        )
    }
}
export default About;